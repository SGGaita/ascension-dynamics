"use client";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { brand } from "@/lib/theme";

interface Props {
  eyebrow: string;
  title: React.ReactNode;
  intro?: string;
  align?: "left" | "center";
}

export default function SectionHeading({ eyebrow, title, intro, align = "left" }: Props) {
  return (
    <Box sx={{ textAlign: align, maxWidth: align === "center" ? 720 : 760, mx: align === "center" ? "auto" : 0, mb: { xs: 4, md: 6 } }}>
      <Box sx={{ display: "inline-flex", alignItems: "center", gap: 1.25, mb: 1.5 }}>
        <Box sx={{ width: 28, height: 3, borderRadius: 2, background: brand.gradient }} />
        <Typography variant="overline" sx={{ color: brand.teal }}>{eyebrow}</Typography>
      </Box>
      <Typography variant="h2" sx={{ fontSize: { xs: "1.9rem", md: "2.6rem" } }}>{title}</Typography>
      {intro && (
        <Typography variant="body1" sx={{ mt: 2, color: brand.body, fontSize: { md: "1.08rem" } }}>{intro}</Typography>
      )}
    </Box>
  );
}
