"use client";
import Link from "next/link";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import MuiLink from "@mui/material/Link";
import Divider from "@mui/material/Divider";
import BrandLogo from "./BrandLogo";
import { NAV_LINKS } from "./SiteHeader";
import { brand } from "@/lib/theme";

interface FooterProps {
  email?: string;
  locations?: string;
  phone?: string;
}

export default function SiteFooter({ email = "hello@ascensiondynamics.io", locations, phone }: FooterProps) {
  return (
    <Box component="footer" sx={{ bgcolor: brand.bgAlt, borderTop: `1px solid ${brand.border}`, pt: { xs: 6, md: 8 }, pb: 4 }}>
      <Container maxWidth="lg">
        <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1.4fr 1fr 1fr" }, gap: { xs: 4, md: 6 } }}>
          <Box>
            <BrandLogo height={72} />
            <Typography variant="body2" sx={{ mt: 2, maxWidth: 360, color: brand.body }}>
              We design and build web platforms and information systems for institutions, associations and growing businesses.
            </Typography>
          </Box>

          <Box>
            <Typography variant="overline" sx={{ color: brand.muted }}>Explore</Typography>
            <Box component="ul" sx={{ listStyle: "none", p: 0, m: 0, mt: 1, display: "grid", gap: 1 }}>
              {NAV_LINKS.map((l) => (
                <li key={l.href}>
                  <MuiLink component={Link} href={l.href} sx={{ color: brand.body }}>{l.label}</MuiLink>
                </li>
              ))}
            </Box>
          </Box>

          <Box>
            <Typography variant="overline" sx={{ color: brand.muted }}>Contact</Typography>
            <Box sx={{ mt: 1, display: "grid", gap: 1 }}>
              <MuiLink href={`mailto:${email}`} sx={{ color: brand.teal, fontWeight: 600 }}>{email}</MuiLink>
              {phone && <Typography variant="body2">{phone}</Typography>}
              {locations && <Typography variant="body2" sx={{ color: brand.body }}>{locations}</Typography>}
            </Box>
          </Box>
        </Box>

        <Divider sx={{ my: 4 }} />
        <Typography variant="caption" sx={{ color: brand.muted }}>
          © {new Date().getFullYear()} Ascension Dynamics Ltd. All rights reserved.
        </Typography>
      </Container>
    </Box>
  );
}
