"use client";
import Link from "next/link";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { brand } from "@/lib/theme";

interface BrandLogoProps {
  /** Height of the AD mark in px (desktop). Mobile scales down ~20%. */
  height?: number;
  src?: string;
  companyName?: string;
  showText?: boolean;
  tagline?: string;
}

/** AD mark (cropped, transparent) + company name rendered as real text. */
export default function BrandLogo({
  height = 56,
  src = "/logo-mark.png",
  companyName = "Ascension Dynamics",
  showText = true,
  tagline = "Creative Web Presence",
}: BrandLogoProps) {
  const name = companyName.replace(".", " ");
  return (
    <Box
      component={Link}
      href="/"
      aria-label={`${name} — home`}
      sx={{ display: "inline-flex", alignItems: "center", gap: 1.5, textDecoration: "none", color: "inherit" }}
    >
      <Box
        component="img"
        src={src}
        alt=""
        sx={{
          height: { xs: Math.round(height * 0.8), md: height },
          width: "auto",
          display: "block",
          flexShrink: 0,
        }}
      />
      {showText && (
        <Box sx={{ display: "flex", flexDirection: "column", lineHeight: 1 }}>
          <Typography
            component="span"
            sx={{
              fontFamily: "'Manrope', sans-serif",
              fontWeight: 800,
              fontSize: { xs: "1.05rem", md: "1.25rem" },
              letterSpacing: "0.02em",
              color: brand.ink,
              lineHeight: 1.1,
              textTransform: "uppercase",
            }}
          >
            {name}
          </Typography>
          {tagline && (
            <Typography
              component="span"
              sx={{ fontSize: { xs: "0.72rem", md: "0.8rem" }, color: brand.muted, mt: 0.4, letterSpacing: "0.02em" }}
            >
              {tagline}
            </Typography>
          )}
        </Box>
      )}
    </Box>
  );
}
