"use client";
import Link from "next/link";
import Card from "@mui/material/Card";
import CardActionArea from "@mui/material/CardActionArea";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";
import { ArrowForwardIcon, CalendarTodayOutlinedIcon } from "./icons";
import type { Project } from "@/lib/projects";
import { brand } from "@/lib/theme";

export function StatusChip({ status }: { status: Project["status"] }) {
  const live = status === "Live" || status === "Maintained";
  return (
    <Chip
      size="small"
      label={status}
      icon={<Box component="span" sx={{ width: 7, height: 7, borderRadius: "50%", bgcolor: live ? "#2E9D5B" : "#D98A00", ml: "8px !important" }} />}
      sx={{ bgcolor: "#fff", border: `1px solid ${brand.border}`, color: brand.body, fontSize: "0.72rem" }}
    />
  );
}

export default function ProjectCard({ project, compact = false }: { project: Project; compact?: boolean }) {
  const p = project;
  const techShown = compact ? p.tech.slice(0, 3) : p.tech.slice(0, 5);
  const more = p.tech.length - techShown.length;

  return (
    <Card
      sx={{
        height: "100%",
        transition: "transform .2s ease, box-shadow .2s ease, border-color .2s",
        "&:hover": { transform: "translateY(-4px)", boxShadow: "0 18px 40px rgba(13,27,62,0.10)", borderColor: "transparent" },
      }}
    >
      <CardActionArea component={Link} href={`/projects/${p.slug}`} sx={{ height: "100%", display: "flex", flexDirection: "column", alignItems: "stretch" }}>
        <Box sx={{ height: 6, bgcolor: p.accent }} />
        <Box sx={{ p: { xs: 2.5, md: compact ? 2.75 : 3.5 }, display: "flex", flexDirection: "column", flex: 1, gap: 1.5 }}>
          <Stack direction="row" spacing={1} sx={{ alignItems: "center", justifyContent: "space-between" }}>
            <Typography variant="overline" sx={{ color: p.accent, fontSize: "0.7rem" }}>{p.category}</Typography>
            {!compact && <StatusChip status={p.status} />}
          </Stack>

          <Typography variant={compact ? "h6" : "h4"} component="h3" sx={{ fontSize: compact ? undefined : { xs: "1.4rem", md: "1.65rem" } }}>
            {p.title}
          </Typography>

          <Stack direction="row" spacing={1} sx={{ alignItems: "center", color: brand.muted }}>
            <CalendarTodayOutlinedIcon sx={{ fontSize: 16 }} />
            <Typography variant="body2" sx={{ color: brand.muted }}>
              <strong style={{ color: brand.ink }}>{p.year}</strong> · {p.period}
            </Typography>
          </Stack>

          <Typography variant="body2" sx={{ color: brand.body, flex: compact ? 0 : 1 }}>
            {p.shortDesc}
          </Typography>

          {!compact && (
            <Box>
              <Typography variant="caption" sx={{ color: brand.muted, fontWeight: 600, display: "block", mb: 0.75 }}>
                Scope of work
              </Typography>
              <Typography variant="body2" sx={{ color: brand.body }}>
                {p.scope.slice(0, 3).join(" · ")}{p.scope.length > 3 ? " …" : ""}
              </Typography>
            </Box>
          )}

          <Stack direction="row" useFlexGap sx={{ flexWrap: "wrap", gap: 0.75, mt: "auto", pt: 1 }}>
            {techShown.map((t) => (
              <Chip key={t} label={t} size="small" sx={{ bgcolor: brand.bgAlt, color: brand.ink }} />
            ))}
            {more > 0 && <Chip label={`+${more}`} size="small" variant="outlined" sx={{ color: brand.muted }} />}
          </Stack>

          <Stack direction="row" spacing={0.75} sx={{ alignItems: "center", color: brand.teal, fontWeight: 600, pt: 1 }}>
            <Typography variant="body2" sx={{ fontWeight: 600, color: "inherit" }}>View case study</Typography>
            <ArrowForwardIcon sx={{ fontSize: 18 }} />
          </Stack>
        </Box>
      </CardActionArea>
    </Card>
  );
}
