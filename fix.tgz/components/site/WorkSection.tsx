"use client";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import SectionHeading from "./SectionHeading";
import ProjectCard from "./ProjectCard";
import type { Project } from "@/lib/projects";

export default function WorkSection({ projects }: { projects: Project[] }) {
  return (
    <Box component="section" id="work" sx={{ py: { xs: 8, md: 12 } }}>
      <Container maxWidth="lg">
        <SectionHeading
          eyebrow="Portfolio"
          title="Selected projects"
          intro="Platforms we have designed, built and launched — each with its scope of work, technology and delivery period."
        />
        <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" }, gap: 3 }}>
          {projects.map((p) => (
            <ProjectCard key={p.slug} project={p} />
          ))}
        </Box>
      </Container>
    </Box>
  );
}
