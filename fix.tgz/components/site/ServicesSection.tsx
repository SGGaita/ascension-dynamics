"use client";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Card from "@mui/material/Card";
import Typography from "@mui/material/Typography";
import { LanguageOutlinedIcon, CloudOutlinedIcon, AutoAwesomeOutlinedIcon, PhoneIphoneOutlinedIcon, ShieldOutlinedIcon, InsightsOutlinedIcon } from "./icons";
import SectionHeading from "./SectionHeading";
import { brand } from "@/lib/theme";
import type { ServiceData } from "@/lib/types";

const ICONS: Array<[RegExp, React.ElementType]> = [
  [/web|platform|site/i, LanguageOutlinedIcon],
  [/cloud|devops/i, CloudOutlinedIcon],
  [/\bai\b|machine|intelligen/i, AutoAwesomeOutlinedIcon],
  [/mobile|app\b/i, PhoneIphoneOutlinedIcon],
  [/secur|complian/i, ShieldOutlinedIcon],
  [/data|analytic|report/i, InsightsOutlinedIcon],
];
const TINTS = [brand.teal, brand.navy, brand.magenta, brand.green];

function ServiceIcon({ title, fallback, color }: { title: string; fallback: string; color: string }) {
  const Icon = ICONS.find(([re]) => re.test(title))?.[1];
  return (
    <Box sx={{ width: 48, height: 48, borderRadius: 3, display: "grid", placeItems: "center", bgcolor: `${color}14`, color, mb: 2.5 }}>
      {Icon ? <Icon /> : <span style={{ fontSize: "1.3rem" }}>{fallback}</span>}
    </Box>
  );
}

export default function ServicesSection({ services }: { services: ServiceData[] }) {
  return (
    <Box component="section" id="services" sx={{ py: { xs: 8, md: 12 }, bgcolor: brand.bgAlt }}>
      <Container maxWidth="lg">
        <SectionHeading
          eyebrow="What we do"
          title="Services built around your organisation"
          intro="From first workshop to production support, we take ownership of the whole delivery — design, engineering, hosting and training."
        />
        <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", md: "repeat(3, 1fr)" }, gap: 2.5 }}>
          {services.map((s, i) => (
            <Card key={s.title} sx={{ p: 3.5, height: "100%" }}>
              <ServiceIcon title={s.title} fallback={s.icon} color={TINTS[i % TINTS.length]} />
              <Typography variant="h6" component="h3" sx={{ mb: 1 }}>{s.title}</Typography>
              <Typography variant="body2" sx={{ color: brand.body }}>{s.desc}</Typography>
            </Card>
          ))}
        </Box>
      </Container>
    </Box>
  );
}
