"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Container from "@mui/material/Container";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import Drawer from "@mui/material/Drawer";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import Divider from "@mui/material/Divider";
import { MenuIcon, CloseIcon } from "./icons";
import BrandLogo from "./BrandLogo";
import { brand } from "@/lib/theme";
import type { NavbarSettings } from "@/lib/types";

export const NAV_LINKS = [
  { label: "Services", href: "/#services" },
  { label: "Work",     href: "/#work" },
  { label: "Process",  href: "/#process" },
  { label: "Contact",  href: "/#contact" },
];

export default function SiteHeader({ settings }: { settings?: NavbarSettings }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Logo is larger than before; CMS values below 48px are bumped up.
  const logoHeight = Math.max(settings?.logoHeight ?? 56, 48);

  return (
    <>
      <AppBar
        position="sticky"
        sx={{
          bgcolor: "rgba(255,255,255,0.92)",
          backdropFilter: "saturate(180%) blur(12px)",
          borderBottom: `1px solid ${scrolled ? brand.border : "transparent"}`,
          boxShadow: scrolled ? "0 4px 24px rgba(13,27,62,0.06)" : "none",
          transition: "box-shadow .2s, border-color .2s",
        }}
      >
        <Container maxWidth="lg">
          <Toolbar disableGutters sx={{ minHeight: { xs: 72, md: 88 }, gap: 2 }}>
            <BrandLogo height={logoHeight} src={settings?.logoUrl} companyName={settings?.companyName} />

            <Box sx={{ flex: 1 }} />

            <Box component="nav" sx={{ display: { xs: "none", md: "flex" }, alignItems: "center", gap: 0.5 }}>
              {NAV_LINKS.map((l) => (
                <Button key={l.href} component={Link} href={l.href} color="inherit" sx={{ color: brand.body, fontWeight: 500, px: 1.75 }}>
                  {l.label}
                </Button>
              ))}
              <Button component={Link} href="/#contact" variant="contained" color="primary" sx={{ ml: 1.5 }}>
                Start a project
              </Button>
            </Box>

            <IconButton
              aria-label="Open menu"
              onClick={() => setOpen(true)}
              sx={{ display: { xs: "inline-flex", md: "none" }, border: `1px solid ${brand.border}`, borderRadius: 2 }}
            >
              <MenuIcon />
            </IconButton>
          </Toolbar>
        </Container>
      </AppBar>

      <Drawer anchor="right" open={open} onClose={() => setOpen(false)} slotProps={{ paper: { sx: { width: "min(320px, 88vw)", p: 2.5 } } }}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 2 }}>
          <BrandLogo height={52} showText={false} src={settings?.logoUrl} />
          <IconButton aria-label="Close menu" onClick={() => setOpen(false)}>
            <CloseIcon />
          </IconButton>
        </Box>
        <Divider />
        <List sx={{ my: 1 }}>
          {NAV_LINKS.map((l) => (
            <ListItemButton key={l.href} component={Link} href={l.href} onClick={() => setOpen(false)} sx={{ borderRadius: 2, py: 1.5 }}>
              <ListItemText primary={l.label} slotProps={{ primary: { sx: { fontFamily: "'Manrope', sans-serif", fontWeight: 700, fontSize: "1.2rem" } } }} />
            </ListItemButton>
          ))}
        </List>
        <Button component={Link} href="/#contact" onClick={() => setOpen(false)} variant="contained" size="large" fullWidth>
          Start a project
        </Button>
      </Drawer>
    </>
  );
}
