"use client";
import { useState } from "react";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Card from "@mui/material/Card";
import Typography from "@mui/material/Typography";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Alert from "@mui/material/Alert";
import MuiLink from "@mui/material/Link";
import { CheckCircleOutlineIcon, MailOutlineIcon, PlaceOutlinedIcon, PhoneOutlinedIcon } from "./icons";
import SectionHeading from "./SectionHeading";
import { brand } from "@/lib/theme";

/* Values below must stay in sync with the mappings in app/api/leads/route.ts */
const SVCS = [
  { id: "web", label: "Web platform" },
  { id: "cld", label: "Cloud & DevOps" },
  { id: "ai",  label: "AI & ML" },
  { id: "mob", label: "Mobile app" },
  { id: "sec", label: "Cybersecurity" },
  { id: "dat", label: "Data & analytics" },
];
const BUDGETS   = ["< $25k", "$25k–$75k", "$75k–$200k", "$200k+", "Enterprise"];
const TIMELINES = ["ASAP", "1–3 months", "3–6 months", "6+ months"];
const SOURCES   = ["Google", "LinkedIn", "Referral", "Event", "Social Media", "Other"];
const STEPS     = ["About you", "Scope & budget", "Project brief"];

type F = {
  fn: string; ln: string; email: string; company: string; role: string;
  svcs: string[]; budget: string; timeline: string;
  pname: string; goals: string; tech: string; links: string; source: string;
};
const BLANK: F = { fn: "", ln: "", email: "", company: "", role: "", svcs: [], budget: "", timeline: "", pname: "", goals: "", tech: "", links: "", source: "" };

interface ContactProps {
  contactInfo?: { email?: string; locations?: string; phone?: string };
}

function ChoiceChips({ options, value, onToggle, error }: { options: { id: string; label: string }[]; value: string[]; onToggle: (id: string) => void; error?: boolean }) {
  return (
    <Stack direction="row" useFlexGap sx={{ flexWrap: "wrap", gap: 1 }}>
      {options.map((o) => {
        const on = value.includes(o.id);
        return (
          <Chip
            key={o.id}
            label={o.label}
            onClick={() => onToggle(o.id)}
            color={on ? "secondary" : "default"}
            variant={on ? "filled" : "outlined"}
            sx={{ borderColor: error && !on ? "error.main" : undefined, fontWeight: 500 }}
          />
        );
      })}
    </Stack>
  );
}

export default function ContactSection({ contactInfo }: ContactProps) {
  const [step, setStep] = useState(0);
  const [f, setF] = useState<F>(BLANK);
  const [e, setE] = useState<Record<string, string>>({});
  const [sent, setSent] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  const email = contactInfo?.email ?? "hello@ascensiondynamics.io";
  const locations = contactInfo?.locations ?? "Nairobi, Kenya";

  const set = <K extends keyof F>(k: K, v: F[K]) => {
    setF((x) => ({ ...x, [k]: v }));
    setE((x) => { const n = { ...x }; delete n[k as string]; return n; });
  };
  const toggleSvc = (id: string) => set("svcs", f.svcs.includes(id) ? f.svcs.filter((s) => s !== id) : [...f.svcs, id]);

  const validate = () => {
    const err: Record<string, string> = {};
    if (step === 0) {
      if (!f.fn.trim()) err.fn = "Required";
      if (!f.ln.trim()) err.ln = "Required";
      if (!/\S+@\S+\.\S+/.test(f.email)) err.email = "Enter a valid email";
      if (!f.company.trim()) err.company = "Required";
    }
    if (step === 1) {
      if (!f.svcs.length) err.svcs = "Select at least one service";
      if (!f.budget) err.budget = "Select a budget";
      if (!f.timeline) err.timeline = "Select a timeline";
    }
    if (step === 2 && f.goals.trim().length < 30) err.goals = "Please add a little more detail (min. 30 characters)";
    setE(err);
    return !Object.keys(err).length;
  };

  const next = () => { if (validate()) setStep((s) => s + 1); };
  const back = () => setStep((s) => s - 1);

  const submit = async () => {
    if (!validate()) return;
    setSubmitting(true);
    setSubmitError("");
    try {
      const res = await fetch("/api/leads", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
      if (!res.ok) throw new Error(String(res.status));
      setSent(true);
      setF(BLANK);
      setStep(0);
    } catch {
      setSubmitError(`We couldn't send your brief. Please try again or email us at ${email}.`);
    } finally {
      setSubmitting(false);
    }
  };

  const info = [
    { icon: <MailOutlineIcon />, node: <MuiLink href={`mailto:${email}`} sx={{ color: brand.ink, fontWeight: 600 }}>{email}</MuiLink> },
    ...(contactInfo?.phone ? [{ icon: <PhoneOutlinedIcon />, node: <Typography>{contactInfo.phone}</Typography> }] : []),
    { icon: <PlaceOutlinedIcon />, node: <Typography sx={{ color: brand.body }}>{locations}</Typography> },
  ];

  return (
    <Box component="section" id="contact" sx={{ py: { xs: 8, md: 12 } }}>
      <Container maxWidth="lg">
        <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "0.9fr 1.3fr" }, gap: { xs: 5, md: 8 }, alignItems: "start" }}>
          <Box>
            <SectionHeading
              eyebrow="Contact"
              title="Let's build something great together"
              intro="Tell us about your project. We reply to every brief within one working day with next steps."
            />
            <Stack spacing={2}>
              {info.map((i, k) => (
                <Stack key={k} direction="row" spacing={1.5} sx={{ alignItems: "center" }}>
                  <Box sx={{ width: 40, height: 40, borderRadius: 2, display: "grid", placeItems: "center", bgcolor: brand.bgAlt, color: brand.teal }}>{i.icon}</Box>
                  {i.node}
                </Stack>
              ))}
            </Stack>
          </Box>

          <Card sx={{ p: { xs: 2.5, md: 4 }, boxShadow: "0 24px 50px rgba(13,27,62,0.07)" }}>
            {sent ? (
              <Box sx={{ textAlign: "center", py: 5 }}>
                <CheckCircleOutlineIcon sx={{ fontSize: 56, color: "#2E9D5B", mb: 2 }} />
                <Typography variant="h5" sx={{ mb: 1 }}>Brief received — thank you!</Typography>
                <Typography sx={{ color: brand.body, mb: 3 }}>Our team will review it and get back to you within one working day.</Typography>
                <Button variant="outlined" onClick={() => setSent(false)}>Send another brief</Button>
              </Box>
            ) : (
              <>
                <Stepper activeStep={step} alternativeLabel sx={{ mb: 4 }}>
                  {STEPS.map((s) => (
                    <Step key={s}><StepLabel>{s}</StepLabel></Step>
                  ))}
                </Stepper>

                {step === 0 && (
                  <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" }, gap: 2 }}>
                    <TextField label="First name" value={f.fn} onChange={(ev) => set("fn", ev.target.value)} error={!!e.fn} helperText={e.fn} required />
                    <TextField label="Last name" value={f.ln} onChange={(ev) => set("ln", ev.target.value)} error={!!e.ln} helperText={e.ln} required />
                    <TextField label="Work email" type="email" value={f.email} onChange={(ev) => set("email", ev.target.value)} error={!!e.email} helperText={e.email} required sx={{ gridColumn: { sm: "1 / -1" } }} />
                    <TextField label="Organisation" value={f.company} onChange={(ev) => set("company", ev.target.value)} error={!!e.company} helperText={e.company} required />
                    <TextField label="Your role (optional)" value={f.role} onChange={(ev) => set("role", ev.target.value)} />
                  </Box>
                )}

                {step === 1 && (
                  <Stack spacing={3}>
                    <Box>
                      <Typography variant="subtitle2" sx={{ mb: 1 }}>Services required</Typography>
                      <ChoiceChips options={SVCS} value={f.svcs} onToggle={toggleSvc} error={!!e.svcs} />
                      {e.svcs && <Typography variant="caption" color="error">{e.svcs}</Typography>}
                    </Box>
                    <Box>
                      <Typography variant="subtitle2" sx={{ mb: 1 }}>Estimated budget</Typography>
                      <ChoiceChips options={BUDGETS.map((b) => ({ id: b, label: b }))} value={[f.budget]} onToggle={(v) => set("budget", v)} error={!!e.budget} />
                      {e.budget && <Typography variant="caption" color="error">{e.budget}</Typography>}
                    </Box>
                    <Box>
                      <Typography variant="subtitle2" sx={{ mb: 1 }}>Desired timeline</Typography>
                      <ChoiceChips options={TIMELINES.map((t) => ({ id: t, label: t }))} value={[f.timeline]} onToggle={(v) => set("timeline", v)} error={!!e.timeline} />
                      {e.timeline && <Typography variant="caption" color="error">{e.timeline}</Typography>}
                    </Box>
                  </Stack>
                )}

                {step === 2 && (
                  <Stack spacing={2}>
                    <TextField label="Project name (optional)" value={f.pname} onChange={(ev) => set("pname", ev.target.value)} />
                    <TextField
                      label="Goals & description"
                      multiline
                      minRows={4}
                      value={f.goals}
                      onChange={(ev) => set("goals", ev.target.value)}
                      error={!!e.goals}
                      helperText={e.goals || `${f.goals.length} characters`}
                      required
                    />
                    <TextField label="Existing tech stack / constraints (optional)" value={f.tech} onChange={(ev) => set("tech", ev.target.value)} />
                    <TextField label="Reference links (optional)" value={f.links} onChange={(ev) => set("links", ev.target.value)} />
                    <Box>
                      <Typography variant="subtitle2" sx={{ mb: 1 }}>How did you hear about us?</Typography>
                      <ChoiceChips options={SOURCES.map((s) => ({ id: s, label: s }))} value={[f.source]} onToggle={(v) => set("source", v)} />
                    </Box>
                  </Stack>
                )}

                {submitError && <Alert severity="error" sx={{ mt: 3 }}>{submitError}</Alert>}

                <Stack direction="row" sx={{ justifyContent: "space-between", alignItems: "center", mt: 4, pt: 3, borderTop: `1px solid ${brand.border}` }}>
                  {step > 0 ? <Button onClick={back} color="inherit">Back</Button> : <span />}
                  <Stack direction="row" spacing={2} sx={{ alignItems: "center" }}>
                    <Typography variant="caption" sx={{ color: brand.muted }}>Step {step + 1} of {STEPS.length}</Typography>
                    {step < STEPS.length - 1 ? (
                      <Button variant="contained" onClick={next}>Continue</Button>
                    ) : (
                      <Button variant="contained" color="secondary" onClick={submit} disabled={submitting}>
                        {submitting ? "Sending…" : "Submit brief"}
                      </Button>
                    )}
                  </Stack>
                </Stack>
              </>
            )}
          </Card>
        </Box>
      </Container>
    </Box>
  );
}
