"use client";
import Link from "next/link";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Card from "@mui/material/Card";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";
import Divider from "@mui/material/Divider";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import MuiLink from "@mui/material/Link";
import { ArrowBackIcon, OpenInNewIcon, CheckIcon } from "./icons";
import SiteHeader from "./SiteHeader";
import SiteFooter from "./SiteFooter";
import ProjectCard, { StatusChip } from "./ProjectCard";
import { brand } from "@/lib/theme";
import type { Project } from "@/lib/projects";
import type { SiteSettings } from "@/lib/types";

function Fact({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <Box sx={{ py: 1.5, borderBottom: `1px solid ${brand.border}`, "&:last-of-type": { borderBottom: "none" } }}>
      <Typography variant="caption" sx={{ color: brand.muted, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>{label}</Typography>
      <Box sx={{ mt: 0.25, fontWeight: 600, color: brand.ink }}>{children}</Box>
    </Box>
  );
}

function SectionTitle({ children, accent }: { children: React.ReactNode; accent: string }) {
  return (
    <Stack direction="row" spacing={1.25} sx={{ alignItems: "center", mb: 2.5 }}>
      <Box sx={{ width: 4, height: 22, borderRadius: 2, bgcolor: accent }} />
      <Typography variant="h5" component="h2">{children}</Typography>
    </Stack>
  );
}

interface Props {
  project: Project;
  others: Project[];
  siteSettings?: SiteSettings;
}

export default function ProjectDetail({ project: p, others, siteSettings }: Props) {
  const contact = siteSettings?.contact;
  const host = p.liveUrl ? p.liveUrl.replace(/^https?:\/\//, "").replace(/\/$/, "") : "";

  return (
    <>
      <SiteHeader settings={siteSettings?.navbar} />

      <main>
        {/* Hero */}
        <Box sx={{ bgcolor: brand.bgAlt, borderBottom: `1px solid ${brand.border}`, position: "relative" }}>
          <Box sx={{ position: "absolute", top: 0, left: 0, right: 0, height: 4, bgcolor: p.accent }} />
          <Container maxWidth="lg" sx={{ py: { xs: 5, md: 8 } }}>
            <Breadcrumbs sx={{ mb: 3, fontSize: "0.9rem" }}>
              <MuiLink component={Link} href="/" sx={{ color: brand.muted }}>Home</MuiLink>
              <MuiLink component={Link} href="/#work" sx={{ color: brand.muted }}>Work</MuiLink>
              <Typography sx={{ color: brand.ink, fontSize: "inherit" }}>{p.title}</Typography>
            </Breadcrumbs>

            <Stack direction="row" spacing={1} sx={{ alignItems: "center", mb: 2, flexWrap: "wrap" }}>
              <Typography variant="overline" sx={{ color: p.accent }}>{p.category}</Typography>
              <StatusChip status={p.status} />
            </Stack>
            <Typography variant="h1" sx={{ fontSize: { xs: "2.3rem", md: "3.4rem" }, mb: 2 }}>{p.title}</Typography>
            <Typography sx={{ fontSize: { xs: "1.05rem", md: "1.2rem" }, color: brand.body, maxWidth: 760, mb: 4 }}>{p.shortDesc}</Typography>

            <Stack direction={{ xs: "column", sm: "row" }} spacing={1.5}>
              {p.liveUrl && (
                <Button href={p.liveUrl} target="_blank" rel="noopener noreferrer" variant="contained" size="large" endIcon={<OpenInNewIcon />}>
                  Visit live site
                </Button>
              )}
              <Button component={Link} href="/#work" variant="outlined" size="large" startIcon={<ArrowBackIcon />} sx={{ bgcolor: "#fff", borderColor: brand.border }}>
                All projects
              </Button>
            </Stack>
          </Container>
        </Box>

        {/* Body */}
        <Container maxWidth="lg" sx={{ py: { xs: 6, md: 10 } }}>
          <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1fr 340px" }, gap: { xs: 6, md: 8 }, alignItems: "start" }}>
            <Box>
              <Box component="section" sx={{ mb: 7 }}>
                <SectionTitle accent={p.accent}>Description</SectionTitle>
                <Typography sx={{ color: brand.body, fontSize: { md: "1.08rem" }, lineHeight: 1.85 }}>{p.description}</Typography>
              </Box>

              <Box component="section" sx={{ mb: 7 }}>
                <SectionTitle accent={p.accent}>Scope of work</SectionTitle>
                <Box component="ol" sx={{ listStyle: "none", p: 0, m: 0, display: "grid", gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" }, gap: 1.5 }}>
                  {p.scope.map((s, i) => (
                    <Box component="li" key={s} sx={{ display: "flex", gap: 1.5, p: 2, border: `1px solid ${brand.border}`, borderRadius: "12px", bgcolor: "#fff" }}>
                      <Typography sx={{ fontFamily: "'Manrope', sans-serif", fontWeight: 800, color: p.accent, minWidth: 24 }}>
                        {String(i + 1).padStart(2, "0")}
                      </Typography>
                      <Typography variant="body2" sx={{ color: brand.ink, fontWeight: 500 }}>{s}</Typography>
                    </Box>
                  ))}
                </Box>
              </Box>

              {p.features.length > 0 && (
                <Box component="section" sx={{ mb: 7 }}>
                  <SectionTitle accent={p.accent}>Key features</SectionTitle>
                  <Stack spacing={1.25}>
                    {p.features.map((f) => (
                      <Stack key={f} direction="row" spacing={1.5} sx={{ alignItems: "flex-start" }}>
                        <Box sx={{ width: 24, height: 24, borderRadius: 1.5, bgcolor: `${p.accent}18`, color: p.accent, display: "grid", placeItems: "center", flexShrink: 0, mt: 0.25 }}>
                          <CheckIcon sx={{ fontSize: 16 }} />
                        </Box>
                        <Typography sx={{ color: brand.body }}>{f}</Typography>
                      </Stack>
                    ))}
                  </Stack>
                </Box>
              )}

              <Box component="section">
                <SectionTitle accent={p.accent}>Technology used</SectionTitle>
                <Stack direction="row" useFlexGap sx={{ flexWrap: "wrap", gap: 1 }}>
                  {p.tech.map((t) => (
                    <Chip key={t} label={t} sx={{ bgcolor: brand.bgAlt, color: brand.ink, border: `1px solid ${brand.border}`, fontWeight: 600, height: 36, px: 0.5 }} />
                  ))}
                </Stack>
              </Box>
            </Box>

            {/* Sidebar */}
            <Box sx={{ position: { md: "sticky" }, top: { md: 112 }, display: "grid", gap: 3 }}>
              <Card sx={{ p: 3 }}>
                <Typography variant="overline" sx={{ color: brand.muted }}>Project facts</Typography>
                <Box sx={{ mt: 1 }}>
                  <Fact label="Client">{p.client}</Fact>
                  <Fact label="Year">{p.year}</Fact>
                  <Fact label="Period">{p.period}</Fact>
                  <Fact label="Category">{p.category}</Fact>
                  {p.liveUrl && (
                    <Fact label="Website">
                      <MuiLink href={p.liveUrl} target="_blank" rel="noopener noreferrer" sx={{ color: brand.teal, wordBreak: "break-all" }}>{host}</MuiLink>
                    </Fact>
                  )}
                </Box>
              </Card>

              <Card sx={{ p: 3, bgcolor: brand.navy, color: "#fff", border: "none" }}>
                <Typography variant="h6" sx={{ color: "#fff", mb: 1 }}>Need something similar?</Typography>
                <Typography variant="body2" sx={{ color: "rgba(255,255,255,0.78)", mb: 2.5 }}>
                  Tell us about your project and we&rsquo;ll come back with a plan within one working day.
                </Typography>
                <Button component={Link} href="/#contact" variant="contained" color="secondary" fullWidth>
                  Start a conversation
                </Button>
              </Card>
            </Box>
          </Box>
        </Container>

        {others.length > 0 && (
          <Box sx={{ bgcolor: brand.bgAlt, borderTop: `1px solid ${brand.border}`, py: { xs: 6, md: 9 } }}>
            <Container maxWidth="lg">
              <Typography variant="h4" component="h2" sx={{ mb: 4 }}>More projects</Typography>
              <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", md: "repeat(3, 1fr)" }, gap: 2.5 }}>
                {others.map((o) => <ProjectCard key={o.slug} project={o} compact />)}
              </Box>
            </Container>
          </Box>
        )}
        <Divider />
      </main>

      <SiteFooter email={contact?.email} locations={contact?.locations} phone={contact?.phone} />
    </>
  );
}
