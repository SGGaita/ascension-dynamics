"use client";
import Link from "next/link";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import Chip from "@mui/material/Chip";
import { ArrowForwardIcon } from "./icons";
import { brand } from "@/lib/theme";
import type { SiteSettings } from "@/lib/types";
import type { Project } from "@/lib/projects";

const DEFAULT_BADGES = ["Web Platforms", "Information Systems", "Cloud & DevOps", "Mobile", "Data & Reporting"];
const LEGACY_EYEBROW = /systems online/i;

export default function HeroSection({ hero, projects }: { hero?: SiteSettings["hero"]; projects: Project[] }) {
  const headline = hero?.headline || "We Build Digital Infrastructure That Scales";
  const subtext =
    hero?.subtext ||
    "Ascension Dynamics designs and builds web platforms and information systems for institutions, associations and growing businesses.";
  const badges = hero?.badges?.length ? hero.badges : DEFAULT_BADGES;
  const eyebrow = hero?.statusBadge && !LEGACY_EYEBROW.test(hero.statusBadge) ? hero.statusBadge : "Software studio based in Nairobi, Kenya";
  const ctaPrimary = (hero?.ctaPrimary || "Start a Project").replace(/\s*→\s*$/, "");
  const ctaSecondary = hero?.ctaSecondary || "View Our Work";

  return (
    <Box
      component="section"
      id="home"
      sx={{
        position: "relative",
        overflow: "hidden",
        pt: { xs: 6, md: 10 },
        pb: { xs: 8, md: 12 },
        background: `radial-gradient(900px 420px at 85% 10%, rgba(23,169,176,0.08), transparent 70%),
                     radial-gradient(700px 380px at 0% 100%, rgba(194,24,91,0.05), transparent 70%), #fff`,
      }}
    >
      <Container maxWidth="lg">
        <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1.15fr 0.85fr" }, gap: { xs: 6, md: 8 }, alignItems: "center" }}>
          {/* Copy */}
          <Box>
            <Chip
              label={eyebrow}
              sx={{ mb: 3, bgcolor: "rgba(11,127,134,0.08)", color: brand.teal, fontWeight: 600, border: "1px solid rgba(11,127,134,0.18)" }}
            />
            <Typography variant="h1" sx={{ fontSize: { xs: "2.4rem", sm: "3rem", md: "3.6rem" }, mb: 2.5 }}>
              {headline}
            </Typography>
            <Typography variant="body1" sx={{ fontSize: { xs: "1.05rem", md: "1.18rem" }, color: brand.body, maxWidth: 580, mb: 4 }}>
              {subtext}
            </Typography>

            <Stack direction={{ xs: "column", sm: "row" }} spacing={1.5} sx={{ mb: 4 }}>
              <Button component={Link} href="/#contact" variant="contained" size="large" endIcon={<ArrowForwardIcon />}>
                {ctaPrimary}
              </Button>
              <Button component={Link} href="/#work" variant="outlined" size="large" color="primary" sx={{ borderColor: brand.border, bgcolor: "#fff" }}>
                {ctaSecondary}
              </Button>
            </Stack>

            <Stack direction="row" useFlexGap sx={{ flexWrap: "wrap", gap: 1 }}>
              {badges.map((b) => (
                <Chip key={b} label={b} variant="outlined" sx={{ borderColor: brand.border, color: brand.body, bgcolor: "#fff" }} />
              ))}
            </Stack>
          </Box>

          {/* Logo + recent work panel */}
          <Box
            sx={{
              position: "relative",
              overflow: "hidden",
              borderRadius: "24px",
              border: `1px solid ${brand.border}`,
              bgcolor: "#fff",
              boxShadow: "0 30px 60px rgba(13,27,62,0.08)",
              p: { xs: 3, md: 4 },
            }}
          >
            <Box sx={{ position: "absolute", top: 0, left: 0, right: 0, height: 5, background: brand.gradient }} />
            <Box sx={{ display: "flex", justifyContent: "center", py: { xs: 2, md: 3 } }}>
              <Box component="img" src="/logo-mark.png" alt="Ascension Dynamics" sx={{ width: { xs: 200, md: 260 }, height: "auto" }} />
            </Box>
            <Typography variant="overline" sx={{ color: brand.muted, display: "block", mt: 1, mb: 1 }}>
              Recent work
            </Typography>
            <Box component="ul" sx={{ listStyle: "none", p: 0, m: 0 }}>
              {projects.slice(0, 4).map((p, i) => (
                <Box
                  component="li"
                  key={p.slug}
                  sx={{ borderTop: i ? `1px solid ${brand.border}` : "none" }}
                >
                  <Box
                    component={Link}
                    href={`/projects/${p.slug}`}
                    sx={{
                      display: "flex", alignItems: "center", gap: 1.5, py: 1.25, textDecoration: "none", color: brand.ink,
                      "&:hover .t": { color: brand.teal },
                    }}
                  >
                    <Box sx={{ width: 10, height: 10, borderRadius: "3px", bgcolor: p.accent, flexShrink: 0 }} />
                    <Typography className="t" sx={{ fontWeight: 600, flex: 1, transition: "color .15s" }}>{p.title}</Typography>
                    <Typography variant="body2" sx={{ color: brand.muted }}>{p.year}</Typography>
                  </Box>
                </Box>
              ))}
            </Box>
          </Box>
        </Box>
      </Container>
    </Box>
  );
}
