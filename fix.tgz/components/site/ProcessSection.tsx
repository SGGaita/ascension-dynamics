"use client";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import SectionHeading from "./SectionHeading";
import { brand } from "@/lib/theme";

const STEPS = [
  { n: "01", t: "Discover",  d: "Workshops with your team to map users, workflows and success measures." },
  { n: "02", t: "Design",    d: "Information architecture, wireframes and a clickable prototype you can test." },
  { n: "03", t: "Build",     d: "Iterative development with demos every sprint and a shared staging site." },
  { n: "04", t: "Launch & support", d: "Deployment, training and ongoing maintenance so the platform keeps improving." },
];

export default function ProcessSection() {
  return (
    <Box component="section" id="process" sx={{ py: { xs: 8, md: 12 }, bgcolor: brand.bgAlt }}>
      <Container maxWidth="lg">
        <SectionHeading eyebrow="How we work" title="A clear process, from idea to launch" />
        <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", md: "repeat(4, 1fr)" }, gap: { xs: 3, md: 4 } }}>
          {STEPS.map((s) => (
            <Box key={s.n} sx={{ borderTop: `2px solid ${brand.border}`, pt: 3, position: "relative" }}>
              <Box sx={{ position: "absolute", top: -2, left: 0, width: 48, height: 2, background: brand.gradient }} />
              <Typography sx={{ fontFamily: "'Manrope', sans-serif", fontWeight: 800, color: brand.teal, mb: 1 }}>{s.n}</Typography>
              <Typography variant="h6" component="h3" sx={{ mb: 1 }}>{s.t}</Typography>
              <Typography variant="body2" sx={{ color: brand.body }}>{s.d}</Typography>
            </Box>
          ))}
        </Box>
      </Container>
    </Box>
  );
}
